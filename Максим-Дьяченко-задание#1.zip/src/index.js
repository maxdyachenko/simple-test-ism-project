import './styles/app.styl';
import './styles/fonts/catamaran.styl';
import './styles/fonts/gotham.styl';
import './styles/fonts/playfair.styl';
import './styles/fonts/opensans.styl';
import 'font-awesome/css/font-awesome.min.css'
import 'linearicons'

